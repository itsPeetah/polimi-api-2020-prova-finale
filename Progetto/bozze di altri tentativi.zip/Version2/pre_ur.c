#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TEXT_BLOCK_SIZE 8
#define RESTORE_SAMPLE_FREQUENCY 7

#define CHANGE 'c'
#define PRINT 'p'
#define DELETE 'd'
#define QUIT 'q'
#define UNDO 'u'
#define REDO 'r'
#define RESTORE 'z'
#define SKIP 0

#define COMMAND_CODE in_buf[in_len-2]
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

/* ===================================================================== */
/* typedefs */

typedef struct line{
    int len;
    char *body;
}line_t;

typedef line_t* text_t;



/* ===================================================================== */
/* Globals */

text_t text = NULL;
int t_len = 0;
int t_cap = 0;

char status = 0;

char *in_buf;
size_t in_size;
ssize_t in_len;


/* ===================================================================== */
/* Input handling */

void GetInput(){
    in_len = getline(&in_buf, &in_size, stdin);
}

/* ===================================================================== */
/* Text managing */

void AllocateText(int len)
{
    int cap = t_cap;
    while(len > cap) cap += TEXT_BLOCK_SIZE;
    while(len <= cap - TEXT_BLOCK_SIZE) cap -= TEXT_BLOCK_SIZE;

    if(cap < t_cap)
    {
        int curs = cap;
        while (curs < t_cap){
            if(text[curs].body != NULL) free(text[curs].body);
            curs++;
        }
    }

    text = (line_t*)realloc(text, cap * sizeof(line_t));
    for(int i = t_cap; i < cap; i++) text[i].body = NULL;
    
    t_cap = cap;
}

void SetTextLength(int len){

    AllocateText(len);
    t_len = len;
}

void FreeLine(int index){
    free(text[index].body);
    text[index].body = NULL;
}

void SetLine(int index, char** content, int size){
    text[index].len = size;
    text[index].body = (char*)realloc(text[index].body, size * sizeof(char));
    strcpy(text[index].body, (*content));
}

/* ===================================================================== */
/* User actions */

void Print(int from, int to)
{
    for(int i = from; i <= to; i++){
        if(i > 0 && i <= t_len) printf("%s", text[i-1].body);
        else printf(".\n");
    }
}

void Change(int from, int to)
{
    int prev_len = t_len;
    SetTextLength(MAX(to,prev_len));

    for(int i = from - 1; i < to; i++){
        
        // if(i < prevLength) FreeLine(i);

        GetInput();
        SetLine(i, &in_buf, in_size);
    }

}

void Delete(int from, int to)
{
    if(to < 1 || from > t_len){
        // No effect
        return;
    }

    int last2remove = MIN(to, t_len);
    int offset = last2remove - from + 1;

    int curs = from - 1;
    while(curs + offset < t_len){
        
        SetLine(curs, &text[curs+offset].body, text[curs+offset].len);

        curs++;
    }

    SetTextLength(t_len-offset);
}

/* ===================================================================== */
/* Main */

int main(int argc, char** argv)
{
    int arg1, arg2;

    while(status != QUIT){

        GetInput();

        switch (status = COMMAND_CODE)
        {
        case PRINT:
            sscanf(in_buf, "%d,%dp", &arg1, &arg2);
            Print(arg1, arg2);
            break;
        case CHANGE:
            sscanf(in_buf, "%d,%dc", &arg1, &arg2);
            Change(arg1, arg2);
            break;
        case DELETE:
            sscanf(in_buf, "%d,%dd", &arg1, &arg2);
            Delete(arg1, arg2);
            break;
        case UNDO:
            printf("U\n");
            break;
        case REDO:
            printf("R\n");
            break;
        }
    }

    return 0;
}