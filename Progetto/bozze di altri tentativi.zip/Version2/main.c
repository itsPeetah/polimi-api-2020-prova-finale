#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TEXT_BLOCK_SIZE 8
#define STATE_BLOCK_SIZE 4
#define RESTORE_SAMPLE_FREQUENCY 7

#define CHANGE 'c'
#define PRINT 'p'
#define DELETE 'd'
#define QUIT 'q'
#define UNDO 'u'
#define REDO 'r'
#define RESTORE 'z'
#define SKIP 0

#define COMMAND_CODE in_buf[in_len-2]
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

/* ===================================================================== */
/* typedefs */

typedef struct line{
    int len;
    char *body;
}line_t;

typedef line_t* text_t;

typedef struct edit{
    char code;
    int loc;
    int text_len;
    int size;
    text_t lines;
}edit_t;

typedef struct state{
    edit_t *undo, *redo;
}state_t;

typedef state_t* history_t;

/* ===================================================================== */
/* Globals */

text_t text = NULL;
int t_len = 0;
int t_cap = 0;

char status = 0;

history_t history = NULL;
int s_cap;
int s_count = 0;
int s_curr = 0;

char *in_buf = NULL;
size_t in_size = 0;
ssize_t in_len = 0;


/* ===================================================================== */
/* Input handling */

void GetInput(){
    in_len = getline(&in_buf, &in_size, stdin);
}

/* ===================================================================== */
/* Text managing */

void AllocateText(int len)
{
    int cap = t_cap;
    while(len > cap) cap += TEXT_BLOCK_SIZE;
    while(len <= cap - TEXT_BLOCK_SIZE) cap -= TEXT_BLOCK_SIZE;

    if(cap < t_cap)
    {
        int curs = cap;
        while (curs < t_cap){
            if(text[curs].body != NULL) free(text[curs].body);
            curs++;
        }
    }

    text = (line_t*)realloc(text, cap * sizeof(line_t));
    for(int i = t_cap; i < cap; i++) text[i].body = NULL;
    
    t_cap = cap;
}

void SetTextLength(int len)
{

    AllocateText(len);
    t_len = len;
}

void FreeLine(int index)
{
    free(text[index].body);
    text[index].body = NULL;
}

void SetLine(int index, char** content, int size)
{
    text[index].len = size;
    text[index].body = (char*)realloc(text[index].body, size * sizeof(char));
    strcpy(text[index].body, (*content));
}

/* ===================================================================== */
/* User actions */

void UpdateHistory()
{
    int cap = s_cap;
    int count = s_count;
    
    // Updating from the present
    if (s_curr >= count - 1) count++;
    // Updating from the past
    else count = s_curr + 2;

    // Find right capacity
    while(count > cap) cap += STATE_BLOCK_SIZE;
    while(count <= cap - STATE_BLOCK_SIZE) cap -= STATE_BLOCK_SIZE;

    // If shrunk then free states
    if(cap < s_cap){
        int curs = cap;
        while (curs < s_cap){

            edit_t *u = history[curs].undo;
            edit_t *r = history[curs].redo;

            // Free lines for each state
            if(u != NULL && r != NULL)
            {
                for(int i = 0; i < MAX(u->size, r->size); i++){
                    if(i < u->size) free(u->lines[i].body);
                    if(i < r->size) free(r->lines[i].body);
                }
                free(u);
                free(r);
            } 
            else if(u != NULL && r == NULL)
            {
                for(int i = 0; i < u->size; i++){
                    free(u->lines[i].body);
                }
                free(u);
            }
            else if(u == NULL && r != NULL)
            {
                for(int i = 0; i < r->size; i++){
                    free(r->lines[i].body);
                }
                free(r);
            }
            
            curs++;
        }
    }

    history = (state_t*)realloc(history, cap * sizeof(state_t));
    for(int i = s_cap; i < cap; i++) {
        history[i].undo = NULL;
        history[i].redo = NULL;
    }
    
    s_count = count;
    s_cap = cap;
}

edit_t *CreateEdit(char code, int text_len, int loc, int size, char ctx)
{
    edit_t *e = (edit_t*)malloc(sizeof(edit_t));
    e->code = code;
    e->text_len = text_len;
    e->loc = loc;
    e->size = size;
    e->lines = (code == DELETE && ctx == REDO) ? NULL : (line_t*)calloc(size, sizeof(line_t));

    return e;
}

void CopyLineToEdit(edit_t* e, int index_edit, int index_text)
{
    e->lines[index_edit].len = text[index_text].len;
    e->lines[index_edit].body = (char*)realloc(e->lines[index_edit].body, text[index_text].len * sizeof(char));
    strcpy(e->lines[index_edit].body, text[index_text].body);
}

/* ===================================================================== */
/* Navigation */

int CalculateTargetState(int steps)
{
    int target = s_curr + steps;
    if(target < 0) target = 0;
    else if (target > s_count - 1) target = s_count - 1;

    return target;
}

// int FindClosestSamplePoint(int to)
// {
//     int remainder = to%RESTORE_SAMPLE_FREQUENCY;
//     int closest = to - remainder;
//     if(remainder > RESTORE_SAMPLE_FREQUENCY/2 && closest + RESTORE_SAMPLE_FREQUENCY < s_count - 1) 
//         closest += RESTORE_SAMPLE_FREQUENCY; 
//     return closest;
// }

/* ===================================================================== */
/* User actions */

void Print(int from, int to)
{
    for(int i = from; i <= to; i++){
        if(i > 0 && i <= t_len) printf("%s", text[i-1].body);
        else printf(".\n");
    }
}

void Change(int from, int to)
{
    UpdateHistory();

    int prev_len = t_len;
    SetTextLength(MAX(to,prev_len));

    edit_t* r = history[s_curr].redo = CreateEdit(CHANGE,t_len, from - 1, to - from + 1, REDO);
    edit_t* u = history[s_curr+1].undo = CreateEdit(CHANGE, prev_len,from - 1, MIN(to, prev_len) - from + 1, UNDO);

    for(int i = from - 1; i < to; i++){
        
        // Add line to undo
        if(i < prev_len)
        {
            CopyLineToEdit(u, i-from+1, i);

            // u->lines[i].len = text[i].len;
            // u->lines[i].body = (char*)realloc(u->lines[i].body, text[i].len * sizeof(char));
            // strcpy(u->lines[i].body, text[i].body);
        }

        GetInput();
        SetLine(i, &in_buf, in_size);

        CopyLineToEdit(r, i-from+1, i);

        // r->lines[i-from+1].len = text[i].len;
        // r->lines[i-from+1].body = (char*)realloc(r->lines[i-from+1].body, text[i].len * sizeof(char));
        // strcpy(r->lines[i-from+1].body, text[i].body);
    }

    s_curr++;
}

void Delete(int from, int to)
{
    UpdateHistory();

    if(to < 1 || from > t_len){
        
        edit_t* r = history[s_curr].redo = CreateEdit(SKIP, 0, 0, 0, REDO);
        edit_t* u = history[s_curr + 1].undo = CreateEdit(SKIP, 0, 0, 0, UNDO);

        s_curr++;

        return;
    }

    int last2remove = MIN(to, t_len);
    int offset = last2remove - from + 1;

    edit_t* r = history[s_curr].redo = CreateEdit(DELETE, t_len-offset, from - 1, offset, REDO);
    edit_t* u = history[s_curr + 1].undo = CreateEdit(DELETE, t_len, from - 1, offset, UNDO);

    int curs = from - 1;
    while(curs + offset < t_len){
        
        printf("A\n");

        if(curs < last2remove){

            printf("B\n");

            CopyLineToEdit(u, curs-from+1, curs);

            // u->lines[curs-from+1].len = text[curs].len;
            // u->lines[curs-from+1].body = (char*)realloc(u->lines[curs-from+1].body, text[curs].len * sizeof(char));
            // strcpy(u->lines[curs-from+1].body, text[curs].body);

        }
        
        SetLine(curs, &text[curs+offset].body, text[curs+offset].len);

        curs++;
    }

    SetTextLength(t_len-offset);

    s_curr++;
}

void Undo(int steps)
{
    edit_t *e;

    while(steps > 0 && history[s_curr].undo != NULL)
    {
        e = history[s_curr].undo;

        switch (e->code)
        {
            case CHANGE:

                SetTextLength(e->text_len);
                
                for(int i = 0; i < e->size; i++)
                {
                    SetLine(e->loc + i, &e->lines[i].body, e->lines[i].len);
                }

                break;
            case DELETE:
                
                SetTextLength(e->text_len);

                for(int i = 0; i<e->size; i++){
                    printf("%s\n", e->lines[i].body);
                }

                int offset = e->size;

                for(int i = t_len - 1; i >= e->loc; i--)
                {
                    if(i >= e->loc + offset)
                    {
                        printf("Shift\n");
                        SetLine(i, &text[i-offset].body, text[i-offset].len);
                    }
                    else
                    {
                        printf("Replace\n");
                        printf("I: %d\n", i);
                        SetLine(i, &e->lines[i - e->loc].body, e->lines[i - e->loc].len);
                    }

                }

                break;
        }
        s_curr--;
        steps--;
    }
}

void Redo(int steps)
{

}

void Restore(int steps)
{
    int target = CalculateTargetState(steps);
    steps = target-s_curr;

    // TODO expands
    if(steps > 0) Redo(steps);
    if(steps < 0) Undo(-steps);
}

/* ===================================================================== */
/* Main */

int main(int argc, char** argv)
{
    UpdateHistory();

    int arg1, arg2;

    while(status != QUIT){

        GetInput();

        switch (status = COMMAND_CODE)
        {
        case PRINT:
            sscanf(in_buf, "%d,%dp", &arg1, &arg2);
            Print(arg1, arg2);
            break;
        case CHANGE:
            sscanf(in_buf, "%d,%dc", &arg1, &arg2);
            Change(arg1, arg2);
            break;
        case DELETE:
            sscanf(in_buf, "%d,%dd", &arg1, &arg2);
            Delete(arg1, arg2);
            break;
        case UNDO:
            sscanf(in_buf, "%du", &arg1);
            Restore(-arg1);
            break;
        case REDO:
            sscanf(in_buf, "%du", &arg1);
            Restore(arg1);
            break;
        }
    }

    return 0;
}