#include <stdio.h>
#include <stdlib.h>

/* ------------------------ Defines ------------------------ */

// Command codes
#define CHANGE 'c'
#define PRINT 'p'
#define DELETE 'd'
#define QUIT 'q'
#define UNDO 'u'
#define REDO 'r'
#define SHOW_ALL 's'

// Constants
#define LINE_BLOCK_SIZE 32
#define TEXT_BLOCK_SIZE 16

// Macros
#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)>(b))?(a):(b))

/* ------------------------ Globals ------------------------ */

// Input
char *in_buf = NULL;
size_t in_size = 0;
ssize_t in_len = 0;

// Line storage
char **lines = NULL;
int l_cap = 0;
int l_count = 0;

// Program state
char status = 0;

int *text = NULL;
int t_cap = 0;
int t_len = 0;

/* ------------------------ Functions ------------------------ */

void GetInput();

void AdjustStorageSize(int fit);
int StoreInputLine();

void SetTextLength(int len);

void OnPrint(int from, int to);
void OnChange(int from, int to);
void OnDelete(int from, int to);


/* ------------------------ Main ------------------------ */

int main(int argc, char **argv){

    // Setup
    AdjustStorageSize(0);
    SetTextLength(0);

    int arg1, arg2;
    while(status != QUIT){
        // Get input
        GetInput();
        
        // Execute input
        switch (status = in_buf[in_len - 2]){
            case PRINT:
                sscanf(in_buf, "%d,%dp", &arg1, &arg2);
                OnPrint(arg1, arg2);
                break;
            case CHANGE:
                sscanf(in_buf, "%d,%dc", &arg1, &arg2);
                OnChange(arg1, arg2);
                break;
            case DELETE:
                sscanf(in_buf, "%d,%dd", &arg1, &arg2);
                OnDelete(arg1, arg2);
                break;
            case UNDO:
                sscanf(in_buf, "%du", &arg1);
                // OnUndo(arg1);
                // QueueUndos(arg1);
                break;
            case REDO:
                sscanf(in_buf, "%dr", &arg1);
                // OnRedo(arg1);
                // QueueRedos(arg1);
                break;
            case SHOW_ALL:
                printf("LINES:\n\n");
                for(int i = 0; i < l_count; i++){
                    printf("%s", lines[i]);
                }
                printf("\nTEXT:\n\n");
                for(int i = 0; i < t_len; i++){
                    printf("%s", lines[text[i]]);
                }
                break;
        }
    }

    return 0;
}


/* ------------------------ Input ------------------------ */

void GetInput(){
    in_buf = NULL;
    in_len = getline(&in_buf, &in_size, stdin);
}

/* ------------------------ Storage ------------------------ */

void AdjustStorageSize(int fit){
    // Keep increasing by block size until it fits
    while(l_cap <= fit) l_cap += LINE_BLOCK_SIZE;
    // Reallocate memory
    lines = (char**)realloc(lines, l_cap*sizeof(char*));
}

int StoreInputLine(){
    // Save line in last free storage place
    lines[l_count] = in_buf;
    // return the last line and increment size
    return l_count++;
}

/* ------------------------ Storage ------------------------ */

void SetTextLength(len){

    // Adjust text capacity
    int capacity = t_cap;
    while(len >= capacity) capacity += TEXT_BLOCK_SIZE;
    if(capacity>t_cap) text=(int*)realloc(text, capacity * sizeof(int));
    
    // Save text data
    t_len = len;
    t_cap = capacity;
}

/* ------------------------ Events ------------------------ */

void OnPrint(int from, int to){
    // Only print lines that are actually in the text
    for(int i = from; i <= to; i++){
        if(i < 1 || i > t_len) printf(".\n");
        else printf("%s", lines[text[i-1]]);
    }
}

void OnChange(int from, int to){

    int prevLen = t_len;
    int offset = to - from + 1;

    // Adjust text and storage size
    if(to > prevLen) SetTextLength(to);
    if(l_count + offset > l_cap) AdjustStorageSize(l_count + offset);

    for(int i = from; i <= to; i++){
        // Add input line to the storage and reference it in the text
        GetInput();
        text[i-1] = StoreInputLine();
    }
}

void OnDelete(int from, int to){
    
    // Skip non valid commands
    if(from > t_len || to < 1) {
        return;
    }

    int lastToRemove = min(to, t_len);
    int offset = lastToRemove - from + 1;

    // Shift text lines to fill "gap"
    int cursor = from - 1;
    while(cursor < t_len){
        if(cursor + offset < t_len){
            text[cursor] = text[cursor+offset];
        }
        cursor++;
    }

    SetTextLength(t_len-offset);
}